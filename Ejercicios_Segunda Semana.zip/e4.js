/*Crea el programa del ejercicio 1, pero esta vez los valores deben de
obtenerse preguntando al usuario.
Pista: variable = prompt(“Introduce…”)*/

var anchura = prompt("Introduce anchura en cm")
var altura = prompt("Introduce altura cm")
var area = anchura*altura
    
alert("El area es: "+area+" cm")