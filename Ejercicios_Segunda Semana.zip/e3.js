/*Crea un programa que, dado un valor fijo de un nombre, una localidad y un
gusto, los muestre por pantalla
Pista: “Hola, mi nombre es “ + variable1 + “\nSoy de”+...*/

var nombre = "Lucas";
var localidad = "Vigo";
var gusto = "comer";

alert("Hola, mi nombre es: " + nombre + "\nSoy de: " + localidad + "\nMe gusta: "+gusto)