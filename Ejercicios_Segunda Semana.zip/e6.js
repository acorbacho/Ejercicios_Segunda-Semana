/*Crea el programa del ejercicio 3, pero esta vez los valores deben obtenerse
preguntando al usuario.*/

var nombre = prompt("Introduce nombre")
var localidad = prompt("Introduce localidad")
var gusto = prompt("Introduce gusto")

alert("Hola, mi nombre es: " + nombre + "\nSoy de: " + localidad + "\nMe gusta: "+gusto)