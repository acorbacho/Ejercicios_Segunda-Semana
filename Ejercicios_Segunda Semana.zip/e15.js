/*Crea un programa que dado un número, calcule la tabla de multiplicar
 (de 1 a 9) y la muestre por pantalla.*/

 var numero = prompt("Introduce un número")

 for (var i = 0; i < 10; i++) {
    alert(numero+" x "+i+" = "+numero*i)
 }