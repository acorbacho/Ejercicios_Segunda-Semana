/*Crea un programa que compare dos datos introducidos por el usuario y
muestre por pantalla si tienen el mismo valor o no.*/

var valor1 = prompt("Introduce el primer valor")
var valor2 = prompt("Introduce el segundo valor")

valor1==valor2? alert("Los datos son iguales") : alert("Los datos no son iguales")
