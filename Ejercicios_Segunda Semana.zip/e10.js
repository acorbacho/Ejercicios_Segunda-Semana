/*Crea un programa que compare dos cadenas de texto y muestre por
pantalla si son la misma.*/

var texto1 = prompt("Introduce una cadena de texto")
var texto2 = prompt("Introduce una cadena de texto")

texto1===texto2? alert("Son la misma cadena de texto") : alert("No son la misma cadena de texto")
