/*Crea un programa que permita calcular las diferentes potencias de 2,
pidiendo al usuario el exponente y mostrando por pantalla el resultado.*/

var exponente = prompt("Introduce el exponente de base 2")

alert("El resultado es: "+2**exponente)