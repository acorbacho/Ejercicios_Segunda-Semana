/*Crea un programa que compruebe, dada la edad introducida por el
usuario, que puede obtener el permiso de conducción (18 años), mostrando
por pantalla True o False.
Pista: El operador ternario ‘?’*/

var edad = prompt("Introduce tu edad")

edad>=18? alert("Puedes obtener el permiso de conducir")
 : alert("No puedes obtener el permiso de conducir")