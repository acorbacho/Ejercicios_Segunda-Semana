/*Crea un programa que recoja el valor introducido por el usuario y calcule el
módulo y lo muestre por pantalla.*/

var dividendo = prompt("Introduce dividendo")
var divisor = prompt("Introduce divisor")

alert("El módulo es: "+dividendo%divisor)