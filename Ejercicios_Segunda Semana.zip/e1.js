/*Crea un programa que, dados unos valores fijos de altura y anchura, calcule
el área de un rectángulo y lo muestre por pantalla.
Pista: a = b x h*/

var anchura = 22;
var altura = 4;
var area= anchura*altura;
    
alert(area);