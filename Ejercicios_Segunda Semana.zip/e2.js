/*Crea un programa que, dado un valor de radio, calcule el área y la longitud
de una circunferencia y lo muestre por pantalla.
Pista: a = pi x r2 , L = 2 x pi x r*/

var radio = 25;

var perimetro = 3.14*radio**2;
var area = 2*3.14*radio;

alert("El área es: "+area+" cm"+" y el perímetro es: "+perimetro+" cm");