/*Crea el programa del ejercicio 2, pero esta vez los valores deben de
obtenerse preguntando al usuario.*/

var radio = prompt("Introduce el radio");

var perimetro = 3.14*radio**2;
var area = 2*3.14*radio;

alert("El área es: "+area+" y el perímetro es: "+perimetro);