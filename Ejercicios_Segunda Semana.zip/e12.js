/*Crea un programa que recoja un dato del usuario, lo incremente en 1, que el
usuario introduzca otro dato y que multiplique el nuevo dato por el anterior
incrementado y lo muestre por pantalla.*/

var valor1 = prompt("Introduce el primer valor")
valor1++
var valor2 = prompt("Introduce el segundo valor")

alert("El valor final es: "+valor1*valor2)